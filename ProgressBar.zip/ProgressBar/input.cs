﻿using progressbar;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace progressbar
{
    public class Input
    {
        public int max = Convert.ToInt32(Console.ReadLine());
        public double value = Convert.ToDouble(Console.ReadLine());
    }
}