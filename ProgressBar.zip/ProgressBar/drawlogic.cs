﻿using progressbar;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProgressBar
{
    public class DrawLogic : Brain
    {
        public void Symbol()
        {
            for (int i = 0; i < (value / max) * 50; i++)
            {
                Console.Write("|");
            }
        }
    }
}
