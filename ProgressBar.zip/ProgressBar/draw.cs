﻿using progressbar;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProgressBar
{
    public class Draw : DrawLogic
    {
        public void DrawPB()
        {
            Console.Write("[");
            Symbol();
            Console.CursorLeft = 50;
            Console.Write("] - ");
            Pers();
        }
    }
}
