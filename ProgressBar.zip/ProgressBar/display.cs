﻿using progressbar;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProgressBar
{
    sealed class Display : Draw
    {
        public static void Main()
        {
            Console.WriteLine("Введите максимум и значение через Enter");
            var dr = new Draw();
            dr.DrawPB();
        }
    }
}
