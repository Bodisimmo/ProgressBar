﻿using progressbar;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProgressBar
{
    public class Brain : Input
    {
        public double Pers()
        {
            double persent = (value / max) * 100;
            Console.Write(persent + "%");
            return persent;

        }
    }
}
